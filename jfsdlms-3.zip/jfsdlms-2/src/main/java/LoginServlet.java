package your.package;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login") // Maps this servlet to the /login URL
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve user input from the login form
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Basic validation logic (replace with DB or external validation)
        // Example hardcoded user (should be fetched from database in real-world applications)
        String validUsername = "admin";
        String validPassword = "password";  // Store hashed password for production apps

        // Validate credentials
        if (validUsername.equals(username) && validPassword.equals(password)) {
            // Create a new session and store the username
            HttpSession session = request.getSession();
            session.setAttribute("username", username);

            // Send success response in JSON format
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.println("{\"success\": true, \"message\": \"Login successful!\"}");
            response.setStatus(HttpServletResponse.SC_OK);  // HTTP 200 OK
        } else {
            // Send error response in JSON format
            response.setContentType("application/json");
            PrintWriter out = response.getWriter();
            out.println("{\"success\": false, \"message\": \"Invalid username or password.\"}");
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);  // HTTP 401 Unauthorized
        }
    }
}
