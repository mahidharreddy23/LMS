package your.package;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/logout") // Maps the servlet to the /logout URL
public class LogoutServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve the current session without creating a new one
        HttpSession session = request.getSession(false);

        // If a session exists, invalidate it
        if (session != null) {
            session.invalidate();
        }

        // Redirect the user to the login page
        response.sendRedirect("login.html");
    }
}
