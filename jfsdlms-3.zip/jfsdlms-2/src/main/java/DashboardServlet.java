<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LMS Dashboard</title>
<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}
header {
    background-color: #4CAF50;
    padding: 10px;
    text-align: center;
    color: white;
}
nav {
    margin: 0;
    padding: 10px;
    background-color: #333;
}
nav ul {
list-style-type: none;
padding: 0;
        }
nav ul li {
    display: inline;
    margin-right: 10px;
}
nav a {
color: white;
text-decoration: none;
padding: 10px;
        }
nav a:hover {
    background-color: #ddd;
    color: black;
}
        .logout {
    background-color: #f44336;
    transition: background-color 0.3s ease;
}
        .logout:hover {
    background-color: #d32f2f;
}
main {
    padding: 20px;
}
    </style>
</head>
<body>

<header>
<h1>Welcome to the LMS Dashboard</h1>
</header>

<nav>
    <ul>
        <li><a href="/courses">My Courses</a></li>
        <li><a href="/profile">Profile</a></li>
        <!-- Ensure logout maps to the correct servlet -->
        <li><a href="#" class="logout" id="logout">Logout</a></li>
    </ul>
</nav>

<main>
    <h2>Dashboard</h2>
<p>Here you can manage your courses, update your profile, and logout when you're done.</p>
</main>

        <script>
        // Add event listener to logout button
        document.getElementById('logout').addEventListener('click', function(event) {
    event.preventDefault();

    // Send a GET request to the logout servlet
    fetch('/logout', {
            method: 'GET',
            credentials: 'same-origin'  // Ensure session cookie is sent
        })
        .then(response => {
    if (response.ok) {
        // Redirect to login page after successful logout
        window.location.href = 'login.html';
    }
        })
        .catch(error => {
            console.error('Logout failed:', error);
        });
});
</script>

</body>
</html>
